package com.example.form.Form.threadpool;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Task implements Runnable{

	private String url;
	private String browser;
	private boolean isElementPresent;

	public Task(String url, String browser) {
		super();
		this.url = url;
		this.browser = browser;
	}

	public Task() {

	}

	public void run() {

		WebDriver driver = null;
		DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setBrowserName(browser);
		if("chrome".equals(browser)) {
			System.setProperty(
		            "webdriver.chrome.driver",
		            "D:/chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
	        driver.get(url);
	        boolean notExists = driver.findElements(By.className("lnXdpd")).isEmpty();
	        if(notExists) {
	        	isElementPresent = false;
	        } else {
	        	isElementPresent = true;
	        }

 

		}

		if("MicrosoftEdge".equals(browser)) {
			System.setProperty(
		            "webdriver.edge.driver",
		            "D:/msedgedriver.exe");
			driver = new EdgeDriver();
	        driver.manage().window().maximize();
	        driver.get(url);
	        boolean notExists = driver.findElements(By.className("lnXdpd")).isEmpty();
	        if(notExists) {
	        	isElementPresent = false;
	        } else {
	        	isElementPresent = true;
	        }
		}
	}
	}	