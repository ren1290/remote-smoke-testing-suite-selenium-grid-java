package com.example.form.Form.controller;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.form.Form.pojo.Form;
import com.example.form.Form.response.TestSuiteResponse;
import com.example.form.Form.threadpool.Task;
import com.example.form.Form.threadpool.TaskSeleniumGrid;

@RestController
public class FormController {
	
	@CrossOrigin(origins = "http://localhost:3000")
	@PostMapping(value = "/submit")
	public ResponseEntity<TestSuiteResponse> submitForm(@RequestBody Form formData) {
		List<String> selectedBrowsers = formData.getBrowsers();
		String url = formData.getUrl();
		TestSuiteResponse response = new TestSuiteResponse();
		ExecutorService pool = Executors.newFixedThreadPool(selectedBrowsers.size());
			for (String browser : selectedBrowsers) {
				//Task t = new Task(url, browser);
				TaskSeleniumGrid t = new TaskSeleniumGrid(url, browser);
				pool.execute(t);
			}
			response.setResponseMessage("Form Submitted Successfully");
			return ResponseEntity.ok(response);				
	}
}
