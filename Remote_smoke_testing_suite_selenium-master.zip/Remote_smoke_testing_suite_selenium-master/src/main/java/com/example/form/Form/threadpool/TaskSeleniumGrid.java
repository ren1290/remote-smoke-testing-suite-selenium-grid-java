package com.example.form.Form.threadpool;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class TaskSeleniumGrid implements Runnable{

	private String url;
	private String browser;
	private boolean isElementPresent;

	public TaskSeleniumGrid(String url, String browser) {
		super();
		this.url = url;
		this.browser = browser;
	}

	public TaskSeleniumGrid() {

	}

	public void run() {

		WebDriver driver = null;
		DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setBrowserName(browser);
		
			
			System.out.println(" Executing on "+browser);
			
			String Node = "http://10.198.81.101:4444/wd/hub";
			try {
				driver = new RemoteWebDriver(new URL(Node), capabilities);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

				// Launch website
				driver.navigate().to(url);
				driver.manage().window().maximize();
				
				
		        boolean notExists = driver.findElements(By.className("lnXdpd")).isEmpty();
		        if(notExists) {
		        	isElementPresent = false;
		        } else {
		        	isElementPresent = true;
		        }
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			finally {
				driver.close();
			}
		


	}
}
